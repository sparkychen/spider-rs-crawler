fn main() {
    println!("yolo");
}
